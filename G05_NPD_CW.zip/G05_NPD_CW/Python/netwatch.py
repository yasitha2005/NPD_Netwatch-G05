#!/usr/bin/env python3
"""
NetWatch Part B - service availability checker.

Purpose : Check whether each service in the shared inventory is answering
          on its TCP port, sequentially or concurrently, detect what has
          changed since the previous run (using set operations), persist
          the results for Part A and the status server, and return an exit
          code from the shared NetWatch scheme.
Authors : Group 05
Date    : September 2026
Usage   : python3 netwatch.py [-i INVENTORY] [-t SECONDS]
                              [-m sequential|concurrent|compare]

Exit codes (shared with Part A - see README "Exit-code scheme"):
    0  OK        every target OPEN
    1  WARNING   at least one non-critical target not OPEN
    2  USAGE     invalid command-line option or value
    3  CRITICAL  at least one critical target not OPEN
    4  FATAL     inventory missing/unreadable/empty, or results not saved
  130  INTERRUPTED by Ctrl+C
"""

import argparse
import csv
import json
import logging
import math
import os
import re
import socket
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_INVENTORY = SCRIPT_DIR.parent / "ShellScript" / "config" / "inventory.csv"
DATA_DIR = SCRIPT_DIR / "data"
REPORTS_DIR = SCRIPT_DIR / "reports"
LOG_DIR = SCRIPT_DIR / "logs"
RESULTS_FILE = DATA_DIR / "results.json"
LOG_FILE = LOG_DIR / "netwatch.log"

DEFAULT_TIMEOUT = 2.0
MAX_TIMEOUT = 60.0
DEFAULT_MODE = "concurrent"
MAX_WORKERS = 20

EXIT_OK = 0
EXIT_WARNING = 1
EXIT_USAGE = 2
EXIT_CRITICAL = 3
EXIT_FATAL = 4
EXIT_INTERRUPTED = 130

# Inventory contract: exactly these five columns, in this order.
EXPECTED_FIELD_COUNT = 5

# Validation rules - identical to validate_inventory() in Part A (INT-01).
NAME_PATTERN = re.compile(r"[A-Za-z0-9._-]+")
OCTET_PATTERN = re.compile(r"25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9]")
PORT_PATTERN = re.compile(r"[0-9]{1,5}")

# Data contract with Part A (INT-03): comma-delimited, one header row,
# no quoting (validation forbids commas in every field), timestamps in
# ISO 8601 with numeric UTC offset, e.g. 2026-09-27T20:15:04+0530.
CSV_FIELDS = [
    "timestamp",
    "hostname",
    "ip_address",
    "service",
    "port",
    "critical",
    "status",
    "response_time_ms",
    "error",
]
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S%z"

logger = logging.getLogger("netwatch.partb")


class InventoryError(Exception):
    """Raised when the inventory cannot be used at all."""

# ----------------------------------------------------------------------
# Command line
# ----------------------------------------------------------------------

def timeout_value(text):
    """argparse type: a finite number of seconds, 0 < t <= MAX_TIMEOUT."""

    try:
        value = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"timeout must be a number, got '{text}'"
        ) from None

    if not math.isfinite(value) or value <= 0 or value > MAX_TIMEOUT:
        raise argparse.ArgumentTypeError(
            f"timeout must be greater than 0 and at most {MAX_TIMEOUT:g} "
            f"seconds, got '{text}'"
        )

    return value

def parse_arguments(argv):
    """Parse and validate command-line arguments (usage errors exit 2)."""

    parser = argparse.ArgumentParser(
        description="NetWatch Part B - TCP service availability checker",
        epilog="Exit codes: 0 OK, 1 WARNING, 2 USAGE, 3 CRITICAL, "
               "4 FATAL, 130 INTERRUPTED",
    )
    parser.add_argument(
        "-i", "--inventory",
        type=Path,
        default=DEFAULT_INVENTORY,
        help=f"inventory CSV (default: {DEFAULT_INVENTORY})",
    )
    parser.add_argument(
        "-t", "--timeout",
        type=timeout_value,
        default=DEFAULT_TIMEOUT,
        help=f"per-connection timeout in seconds (default: {DEFAULT_TIMEOUT:g})",
    )
    parser.add_argument(
        "-m", "--mode",
        choices=["sequential", "concurrent", "compare"],
        default=DEFAULT_MODE,
        help="scan mode; 'compare' runs both and reports the speed-up "
             f"(default: {DEFAULT_MODE})",
    )
    return parser.parse_args(argv)

def configure_logging():
    """Send log records to logs/netwatch.log; carry on if that fails."""

    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    except OSError as exc:
        print(f"WARNING: cannot write log file {LOG_FILE}: {exc}",
              file=sys.stderr)
        handler = logging.NullHandler()

    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    ))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# ----------------------------------------------------------------------
# Inventory (FR-P02)
# ----------------------------------------------------------------------

def is_valid_ipv4(address):
    """True for a dotted-quad IPv4 address with octets 0-255."""

    octets = address.split(".")
    if len(octets) != 4:
        return False
    return all(OCTET_PATTERN.fullmatch(octet) for octet in octets)

def is_valid_port(port):
    """True for an all-digit port in the range 1-65535."""

    return bool(PORT_PATTERN.fullmatch(port)) and 1 <= int(port) <= 65535

def validate_row(line, line_number):
    """
    Validate one inventory line.

    Returns (target, None) for a good row or (None, reason) for a bad one.
    The checks and their order match Part A so both reject the same rows.
    """

    if not line.strip():
        return None, "blank line"

    fields = [field.strip() for field in line.split(",")]

    if len(fields) != EXPECTED_FIELD_COUNT:
        return None, (
            f"wrong field count ({len(fields)}, expected "
            f"{EXPECTED_FIELD_COUNT})"
        )

    hostname, ip_address, service, port, critical = fields
    critical = critical.lower()

    if not NAME_PATTERN.fullmatch(hostname):
        return None, f"invalid hostname '{hostname}'"
    if not is_valid_ipv4(ip_address):
        return None, f"invalid IPv4 address '{ip_address}'"
    if not NAME_PATTERN.fullmatch(service):
        return None, f"invalid service '{service}'"
    if not is_valid_port(port):
        return None, f"invalid port '{port}' (must be 1-65535)"
    if critical not in ("yes", "no"):
        return None, f"critical must be 'yes' or 'no', got '{critical}'"

    target = {
        "line_number": line_number,
        "hostname": hostname,
        "ip_address": ip_address,
        "service": service,
        "port": int(port),
        "critical": critical,
    }
    return target, None

def load_inventory(inventory_path):
    """Read the inventory line by line; return (targets, rejected_count)."""

    targets = []
    rejected_count = 0

    try:
        with open(inventory_path, "r", encoding="utf-8") as inventory_file:
            lines = inventory_file.read().splitlines()
    except FileNotFoundError:
        raise InventoryError(
            f"inventory file not found: {inventory_path}"
        ) from None
    except PermissionError:
        raise InventoryError(
            f"permission denied reading inventory: {inventory_path}"
        ) from None
    except IsADirectoryError:
        raise InventoryError(
            f"inventory path is a directory: {inventory_path}"
        ) from None
    except UnicodeDecodeError:
        raise InventoryError(
            f"inventory is not a UTF-8 text file: {inventory_path}"
        ) from None

    if not lines:
        raise InventoryError(f"inventory file is empty: {inventory_path}")

    # Line 1 is the header row and is skipped, as in Part A.
    for line_number, line in enumerate(lines[1:], start=2):
        target, reason = validate_row(line, line_number)

        if reason is not None:
            rejected_count += 1
            print(f"Line {line_number} rejected: {reason}", file=sys.stderr)
            logger.warning("Inventory line %d rejected: %s",
                           line_number, reason)
            continue

        targets.append(target)
        print(
            f"Line {line_number} accepted: {target['hostname']} "
            f"{target['ip_address']} {target['service']} "
            f"{target['port']} {target['critical']}"
        )

    print(f"\nInventory: {len(targets)} accepted, {rejected_count} rejected")
    logger.info("Inventory %s: %d accepted, %d rejected",
                inventory_path, len(targets), rejected_count)
    return targets, rejected_count

# ----------------------------------------------------------------------
# Checking (FR-P03, FR-P04)
# ----------------------------------------------------------------------

def now_timestamp():
    """Current local time in the shared data-contract format."""

    return datetime.now().astimezone().strftime(TIMESTAMP_FORMAT)

def make_result(target, status, response_time_ms, error):
    """Build one result record. Fields are always accessed by name."""

    return {
        "timestamp": now_timestamp(),
        "hostname": target["hostname"],
        "ip_address": target["ip_address"],
        "service": target["service"],
        "port": target["port"],
        "critical": target["critical"],
        "status": status,
        "response_time_ms": response_time_ms,
        "error": error,
    }

def check_service(target, timeout):
    """
    Try one TCP connection. Failure is returned as a status, never raised.

    OPEN     the three-way handshake completed
    CLOSED   the host answered with a refusal (nothing listening)
    TIMEOUT  no answer within the timeout
    ERROR    any other socket failure (unreachable network, bad address)
    The 'with' block closes the socket on every path.
    """

    status = "ERROR"
    error = ""
    start_time = time.perf_counter()

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((target["ip_address"], target["port"]))
        status = "OPEN"
    except ConnectionRefusedError:
        status = "CLOSED"
        error = "connection refused"
    except socket.timeout:
        status = "TIMEOUT"
        error = f"no reply within {timeout:g}s"
    except socket.gaierror as exc:
        error = f"address could not be resolved: {exc.strerror}"
    except OSError as exc:
        error = exc.strerror or type(exc).__name__

    response_time_ms = round((time.perf_counter() - start_time) * 1000, 3)

    if error:
        logger.info("%s %s:%d %s (%s)", target["hostname"],
                    target["ip_address"], target["port"], status, error)

    return make_result(target, status, response_time_ms, error)

def sort_results(results):
    """Deterministic order regardless of which worker finished first."""

    return sorted(
        results,
        key=lambda result: (
            result["hostname"], result["ip_address"], result["port"]
        ),
    )

def run_sequential(targets, timeout):
    """Check each target in turn."""

    return sort_results([check_service(target, timeout) for target in targets])

def run_concurrent(targets, timeout):
    """
    Check all targets in a thread pool and wait for every one to finish.

    Shared state: each worker only builds and returns its own dict; results
    are collected in the main thread, so no two threads ever write to the
    same list. The one shared stream is the log file, and the logging
    module serialises writes with its own lock.
    """

    if not targets:
        return []

    results = []
    worker_count = min(MAX_WORKERS, len(targets))

    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(check_service, target, timeout): target
            for target in targets
        }

        for future in as_completed(futures):
            target = futures[future]
            try:
                results.append(future.result())
            except (OSError, ValueError, TypeError, RuntimeError) as exc:
                # A worker that raises must not lose the whole run.
                logger.error("Worker for %s:%d raised %s: %s",
                             target["ip_address"], target["port"],
                             type(exc).__name__, exc)
                results.append(make_result(
                    target, "ERROR", 0.0,
                    f"worker failed: {type(exc).__name__}",
                ))

    return sort_results(results)

def run_scan(targets, timeout, mode):
    """Run one scan and return (results, wall-clock seconds)."""

    scan_start = time.perf_counter()

    if mode == "sequential":
        results = run_sequential(targets, timeout)
    else:
        results = run_concurrent(targets, timeout)

    duration = time.perf_counter() - scan_start
    logger.info("%s scan of %d targets took %.3f s",
                mode, len(targets), duration)
    return results, duration

def status_pairs(results):
    """(address, port, status) triples used to compare two result sets."""

    return {
        (result["ip_address"], result["port"], result["status"])
        for result in results
    }

# ----------------------------------------------------------------------
# Output and exit code (FR-P06)
# ----------------------------------------------------------------------

def print_results(results):
    """One aligned line per target."""

    print(f"\n{'HOSTNAME':<20} {'ADDRESS':<16} {'SERVICE':<10} "
          f"{'PORT':>5}  {'STATE':<8} {'TIME (ms)':>10}  DETAIL")
    print("-" * 90)
    for result in results:
        print(
            f"{result['hostname']:<20} {result['ip_address']:<16} "
            f"{result['service']:<10} {result['port']:>5}  "
            f"{result['status']:<8} {result['response_time_ms']:>10.3f}  "
            f"{result['error']}"
        )

# ----------------------------------------------------------------------
# Persistence and change detection (FR-P05)
# ----------------------------------------------------------------------

def load_previous_results():
    """
    Return (previous_results, note). previous_results is None when there
    is no usable previous run; note says why, so the caller can state it.
    """

    if not RESULTS_FILE.exists():
        return None, "no previous results file - this is the first run"

    try:
        with open(RESULTS_FILE, "r", encoding="utf-8") as results_file:
            data = json.load(results_file)
    except json.JSONDecodeError as exc:
        logger.warning("Previous results file %s is corrupt: %s",
                       RESULTS_FILE, exc)
        return None, "previous results file is corrupt - treated as first run"
    except OSError as exc:
        logger.warning("Cannot read previous results %s: %s",
                       RESULTS_FILE, exc)
        return None, "previous results file unreadable - treated as first run"

    results = data.get("results") if isinstance(data, dict) else None

    if not isinstance(results, list) or not all(
        isinstance(item, dict)
        and {"ip_address", "port", "status"} <= item.keys()
        for item in results
    ):
        logger.warning("Previous results file %s has an unexpected layout",
                       RESULTS_FILE)
        return None, (
            "previous results file has an unexpected layout - "
            "treated as first run"
        )

    return results, f"compared with run at {data.get('generated_at', '?')}"

def detect_changes(current, previous):
    """
    Compare two runs by (address, port) using set operations.

    newly_opened = open now,  not open before
    newly_closed = open before, not open now
    unchanged    = in both runs and in neither of the above
    """

    current_all = {(r["ip_address"], r["port"]) for r in current}
    previous_all = {(r["ip_address"], r["port"]) for r in previous}
    current_open = {(r["ip_address"], r["port"])
                    for r in current if r["status"] == "OPEN"}
    previous_open = {(r["ip_address"], r["port"])
                     for r in previous if r["status"] == "OPEN"}

    newly_opened = current_open - previous_open
    newly_closed = previous_open - current_open
    unchanged = (current_all & previous_all) - newly_opened - newly_closed

    return {
        "newly_opened": sorted(newly_opened),
        "newly_closed": sorted(newly_closed),
        "unchanged": sorted(unchanged),
    }

def save_results(results, duration, mode):
    """
    Write data/results.json (for the status server and the next run) and
    reports/py_results_<timestamp>.csv (for Part A). The JSON is written to
    a temporary file and renamed, so a reader never sees half a file.
    Returns the CSV path.
    """

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    document = {
        "generated_at": now_timestamp(),
        "mode": mode,
        "duration_seconds": round(duration, 3),
        "results": results,
    }

    temp_file = RESULTS_FILE.with_suffix(".json.tmp")
    try:
        with open(temp_file, "w", encoding="utf-8") as results_file:
            json.dump(document, results_file, indent=4)
        os.replace(temp_file, RESULTS_FILE)
    finally:
        if temp_file.exists():
            temp_file.unlink()

    csv_path = REPORTS_DIR / (
        f"py_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    )
    with open(csv_path, "w", encoding="utf-8", newline="") as report_file:
        writer = csv.DictWriter(
            report_file,
            fieldnames=CSV_FIELDS,
            quoting=csv.QUOTE_NONE,
            escapechar="\\",
        )
        writer.writeheader()
        writer.writerows(results)

    logger.info("Saved %s and %s", RESULTS_FILE, csv_path)
    return csv_path

def print_changes(changes, note):
    """The three labelled change lists, or an explicit first-run message."""

    print("\nChange detection")
    print("-" * 40)
    print(f"Basis: {note}")

    if changes is None:
        print("No change lists: there is no previous run to compare with.")
        return

    for label, key in (("Newly OPENED", "newly_opened"),
                       ("Newly CLOSED", "newly_closed"),
                       ("Unchanged", "unchanged")):
        pairs = changes[key]
        listed = ", ".join(f"{address}:{port}" for address, port in pairs)
        print(f"{label:<13}({len(pairs)}): {listed or '-'}")

def print_summary(results, duration, mode):
    """Counts by state, per-host availability and the run duration."""

    total = len(results)
    print(f"\nSummary ({mode} mode, {duration:.3f} s)")
    print("-" * 40)

    for state in ("OPEN", "CLOSED", "TIMEOUT", "ERROR"):
        count = sum(1 for result in results if result["status"] == state)
        print(f"{state:<10}: {count:>3}")
    print(f"{'TOTAL':<10}: {total:>3}")

    hosts = {}
    for result in results:
        key = (result["hostname"], result["ip_address"])
        open_count, host_total = hosts.get(key, (0, 0))
        hosts[key] = (open_count + (result["status"] == "OPEN"),
                      host_total + 1)

    print(f"\n{'HOST':<20} {'ADDRESS':<16} {'OPEN':>9}  {'AVAILABILITY':>12}")
    for (hostname, address), (open_count, host_total) in sorted(hosts.items()):
        percent = (open_count / host_total) * 100 if host_total else 0.0
        print(f"{hostname:<20} {address:<16} "
              f"{open_count:>4} / {host_total:<2}  {percent:>11.1f}%")

def decide_exit_code(results):
    """Map the outcome onto the shared NetWatch exit-code scheme."""

    down = [result for result in results if result["status"] != "OPEN"]

    if any(result["critical"] == "yes" for result in down):
        return EXIT_CRITICAL
    if down:
        return EXIT_WARNING
    return EXIT_OK

def status_line(results, exit_code):
    """The single status line that ends every run."""

    down = [result for result in results if result["status"] != "OPEN"]
    critical_down = sum(1 for result in down if result["critical"] == "yes")
    label = {EXIT_OK: "OK", EXIT_WARNING: "WARNING",
             EXIT_CRITICAL: "CRITICAL"}[exit_code]
    return (f"STATUS: {label} - {len(results) - len(down)}/{len(results)} "
            f"services OPEN, {critical_down} critical down "
            f"(exit {exit_code})")


# ----------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------

def run(args):
    """One full Part B run. Returns the exit code."""

    print("NetWatch Part B")
    print(f"Inventory : {args.inventory}")
    print(f"Timeout   : {args.timeout:g} s")
    print(f"Mode      : {args.mode}\n")

    try:
        targets, _rejected = load_inventory(args.inventory)
    except InventoryError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        logger.error("%s", exc)
        return EXIT_FATAL

    if not targets:
        print("ERROR: no valid targets in the inventory - nothing to check.",
              file=sys.stderr)
        logger.error("No valid targets in %s", args.inventory)
        return EXIT_FATAL

    previous, note = load_previous_results()

    if args.mode == "compare":
        seq_results, seq_time = run_scan(targets, args.timeout, "sequential")
        results, duration = run_scan(targets, args.timeout, "concurrent")
        speed_up = seq_time / duration if duration > 0 else 0.0
        identical = status_pairs(seq_results) == status_pairs(results)
        print(f"\nSequential : {seq_time:8.3f} s")
        print(f"Concurrent : {duration:8.3f} s")
        print(f"Speed-up   : {speed_up:8.2f}x")
        print(f"Same result set in both modes: "
              f"{'yes' if identical else 'NO - see log'}")
        if not identical:
            logger.warning("Sequential and concurrent results differ: %s",
                           status_pairs(seq_results) ^ status_pairs(results))
    else:
        results, duration = run_scan(targets, args.timeout, args.mode)

    changes = detect_changes(results, previous) if previous is not None else None

    print_results(results)
    print_summary(results, duration, args.mode)
    print_changes(changes, note)

    try:
        csv_path = save_results(results, duration, args.mode)
    except OSError as exc:
        print(f"ERROR: could not save results: {exc}", file=sys.stderr)
        logger.error("Could not save results: %s", exc)
        return EXIT_FATAL

    print(f"\nResults saved : {RESULTS_FILE}")
    print(f"CSV for Part A: {csv_path}")

    exit_code = decide_exit_code(results)
    line = status_line(results, exit_code)
    logger.info("%s", line)
    print(f"\n{line}")
    return exit_code


def main(argv=None):
    """Parse arguments, run, and turn Ctrl+C into a message."""

    args = parse_arguments(argv)
    configure_logging()

    try:
        return run(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user - no results were saved for this run.",
              file=sys.stderr)
        logger.warning("Run interrupted by Ctrl+C")
        return EXIT_INTERRUPTED


if __name__ == "__main__":
    sys.exit(main())
