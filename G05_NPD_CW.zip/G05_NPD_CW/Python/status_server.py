#!/usr/bin/env python3
"""
NetWatch status server (FR-P07).

Purpose : Publish the most recent Part B results over HTTP so the current
          status can be seen without opening a terminal session.
          GET /        readable plain-text status page (for a browser)
          GET /status  the same status as JSON (for programs)
Authors : Group 05
Date    : September 2026
Usage   : python3 status_server.py [--host 127.0.0.1] [--port 8000]

Binds to 127.0.0.1 by default so the internal topology is not exposed to
the rest of the network; --host 0.0.0.0 would publish it to every host.
Exit codes: 0 clean stop, 2 usage error, 4 could not start (port in use,
permission denied on a privileged port, bad bind address).
"""

import argparse
import errno
import json
import logging
import sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
RESULTS_FILE = SCRIPT_DIR / "data" / "results.json"
LOG_DIR = SCRIPT_DIR / "logs"
LOG_FILE = LOG_DIR / "netwatch.log"

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8000

EXIT_OK = 0
EXIT_FATAL = 4

logger = logging.getLogger("netwatch.status")


def configure_logging():
    """Log to logs/netwatch.log; carry on without a log if that fails."""

    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    except OSError as exc:
        print(f"WARNING: cannot write log file {LOG_FILE}: {exc}",
              file=sys.stderr)
        handler = logging.NullHandler()

    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    ))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


def load_results():
    """
    Read results.json. Returns (document, problem); problem is a sentence
    explaining why there is nothing to show, or None when all is well.
    """

    if not RESULTS_FILE.exists():
        return None, "No results yet - run netwatch.py (or netwatch.sh) first."

    try:
        with open(RESULTS_FILE, "r", encoding="utf-8") as results_file:
            document = json.load(results_file)
    except json.JSONDecodeError as exc:
        logger.error("Results file %s is corrupt: %s", RESULTS_FILE, exc)
        return None, "The results file is corrupt - run netwatch.py again."
    except OSError as exc:
        logger.error("Cannot read %s: %s", RESULTS_FILE, exc)
        return None, "The results file cannot be read."

    if not isinstance(document, dict) or not isinstance(
            document.get("results"), list):
        logger.error("Results file %s has an unexpected layout", RESULTS_FILE)
        return None, "The results file has an unexpected layout."

    return document, None


def build_status():
    """Summarise the stored results. Returns (http_code, status_dict)."""

    document, problem = load_results()
    served_at = datetime.now().astimezone().isoformat(timespec="seconds")

    if problem is not None:
        return 503, {"served_at": served_at, "error": problem}

    results = document["results"]
    total = len(results)
    open_count = sum(1 for r in results if r.get("status") == "OPEN")
    critical_down = sum(
        1 for r in results
        if r.get("critical") == "yes" and r.get("status") != "OPEN"
    )

    if critical_down:
        overall = "CRITICAL"
    elif open_count < total:
        overall = "WARNING"
    else:
        overall = "OK"

    services = sorted(
        results,
        key=lambda r: (str(r.get("hostname", "")), int(r.get("port", 0))),
    )

    return 200, {
        "served_at": served_at,
        "results_generated_at": document.get("generated_at"),
        "overall": overall,
        "total_targets": total,
        "open_services": open_count,
        "not_open_services": total - open_count,
        "critical_down": critical_down,
        "availability_percent": round(open_count / total * 100, 1)
        if total else 0.0,
        "services": services,
    }


def render_text(status):
    """Plain-text, column-aligned version of the status for a browser."""

    if "error" in status:
        return f"NetWatch status\n\n{status['error']}\n"

    lines = [
        "NetWatch - current service status",
        f"Results from : {status['results_generated_at']}",
        f"Overall      : {status['overall']}  "
        f"({status['open_services']}/{status['total_targets']} OPEN, "
        f"{status['critical_down']} critical down, "
        f"{status['availability_percent']}% available)",
        "",
        f"{'HOSTNAME':<20} {'ADDRESS':<16} {'SERVICE':<10} {'PORT':>5}  "
        f"{'CRIT':<4}  {'STATE':<8} DETAIL",
        "-" * 84,
    ]
    for service in status["services"]:
        lines.append(
            f"{service.get('hostname', ''):<20} "
            f"{service.get('ip_address', ''):<16} "
            f"{service.get('service', ''):<10} "
            f"{service.get('port', ''):>5}  "
            f"{service.get('critical', ''):<4}  "
            f"{service.get('status', ''):<8} {service.get('error', '')}"
        )
    return "\n".join(lines) + "\n"


class StatusRequestHandler(BaseHTTPRequestHandler):
    """Answers GET / and GET /status; every request is logged."""

    def send_body(self, code, body, content_type):
        """Send a complete response and close the connection."""

        payload = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        """Route the request by path (any query string is ignored)."""

        path = self.path.split("?", 1)[0]

        if path == "/":
            code, status = build_status()
            self.send_body(code, render_text(status), "text/plain")
        elif path == "/status":
            code, status = build_status()
            self.send_body(code, json.dumps(status, indent=2) + "\n",
                           "application/json")
        else:
            self.send_body(404, "Not found. Try / or /status\n", "text/plain")

    def log_message(self, format_string, *args):
        """Send the one-line-per-request access log to our log file."""

        logger.info("%s %s", self.client_address[0], format_string % args)


def parse_arguments(argv):
    """Parse --host and --port (usage errors exit 2)."""

    parser = argparse.ArgumentParser(
        description="NetWatch HTTP status server"
    )
    parser.add_argument("--host", default=DEFAULT_HOST,
                        help=f"address to bind (default: {DEFAULT_HOST})")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help=f"TCP port to listen on (default: {DEFAULT_PORT})")
    args = parser.parse_args(argv)

    if not 1 <= args.port <= 65535:
        parser.error(f"port must be between 1 and 65535, got {args.port}")

    return args


def main(argv=None):
    """Start the server; stop cleanly on Ctrl+C."""

    args = parse_arguments(argv)
    configure_logging()

    try:
        server = ThreadingHTTPServer((args.host, args.port),
                                     StatusRequestHandler)
    except PermissionError:
        message = (f"permission denied binding to port {args.port} - "
                   "ports below 1024 need root; use a port above 1024")
        print(f"ERROR: {message}", file=sys.stderr)
        logger.error("%s", message)
        return EXIT_FATAL
    except OSError as exc:
        if exc.errno == errno.EADDRINUSE:
            message = (f"port {args.port} is already in use on {args.host} - "
                       "stop the other program or choose --port")
        else:
            message = f"cannot listen on {args.host}:{args.port}: {exc.strerror}"
        print(f"ERROR: {message}", file=sys.stderr)
        logger.error("%s", message)
        return EXIT_FATAL

    logger.info("Status server started on %s:%d", args.host, args.port)
    print("NetWatch status server")
    print(f"  Status page : http://{args.host}:{args.port}/")
    print(f"  JSON        : http://{args.host}:{args.port}/status")
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping NetWatch status server.")
        logger.info("Status server stopped by Ctrl+C")
    finally:
        server.server_close()

    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())