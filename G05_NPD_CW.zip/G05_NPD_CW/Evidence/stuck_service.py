#!/usr/bin/env python3


import socket
import sys
import time

DEFAULT_PORTS = [9999]


def make_stuck_listener(port):
    """Return a listening socket whose accept queue is already full."""

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", port))
    listener.listen(0)

    fillers = []
    for _ in range(3):
        filler = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        filler.setblocking(False)
        try:
            filler.connect(("127.0.0.1", port))
        except BlockingIOError:
            pass
        fillers.append(filler)

    return listener, fillers


def main(argv):
    """Open one stuck listener per port and wait for Ctrl+C."""

    try:
        ports = [int(arg) for arg in argv] or DEFAULT_PORTS
    except ValueError:
        print("usage: stuck_service.py [PORT ...]", file=sys.stderr)
        return 2

    sockets = []
    try:
        for port in ports:
            sockets.append(make_stuck_listener(port))
    except OSError as exc:
        print(f"ERROR: cannot listen: {exc.strerror}", file=sys.stderr)
        return 4

    print(f"Hung service listening (never answering) on 127.0.0.1 "
          f"port(s) {', '.join(map(str, ports))}. Ctrl+C to stop.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        for listener, fillers in sockets:
            for filler in fillers:
                filler.close()
            listener.close()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
