# NetWatch test plan – Group 05

Run `./Evidence/tests/run_tests.sh` with the test estate started (README §3), including `Evidence/stuck_service.py`. Each case writes a
transcript to `Evidence/tests/<ID>.txt` holding the command, the full output and the exit code; that file is the evidence.
25 cases: 6 functional, 11 negative, 3 boundary, 5 failure. **Author**: each member must author at least 4 cases. Authors: COHNDNE252F-008 (Mr. PERERA S K Y R) 9 cases, COHNDNE252F-010 (Mr. AKASH K P L) 8, COHNDNE252F-013 (Mr. DIAS K Y S V) 8.

| Test ID | Author | Category | Objective | Input | Expected result | Actual result | Pass/Fail | Evidence |
|---|---|---|---|---|---|---|---|---|
| TC-F01 | COHNDNE252F-008 | Functional | Full pipeline on the valid inventory; Part A invokes Part B and acts on its exit code (INT-02) | `netwatch.sh`, 7-row inventory, 9090/2121 not started, 9999 hung | 7 accepted; UP + RTT per host; Part B status line shown; history appended; timestamped report on screen and in reports/ with SERVICE column filled; exit 1 (non-critical services down) | As expected, exit 1 | Pass | TC-F01.txt |
| TC-F02 | COHNDNE252F-010 | Functional | Part B sequential scan | `netwatch.py -m sequential` | 4 OPEN, 2 CLOSED (9090, 2121), 1 TIMEOUT (9999); summary, per-host availability, status line; exit 1 | As expected | Pass | TC-F02.txt |
| TC-F03 | COHNDNE252F-010 | Functional | Part B concurrent scan | `netwatch.py -m concurrent` | Same result set as TC-F02, same deterministic order | As expected | Pass | TC-F03.txt |
| TC-F04 | COHNDNE252F-013 | Functional | Both modes timed and results compared | `netwatch.py -m compare` | Sequential and concurrent times and speed-up printed; "Same result set in both modes: yes" | As expected | Pass | TC-F04.txt |
| TC-F05 | COHNDNE252F-008 | Functional | Report generation without probing | `netwatch.sh -r` | Report rebuilt from history + latest Part B CSV; history line count unchanged; exit 0 | As expected | Pass | TC-F05.txt |
| TC-F06 | COHNDNE252F-013 | Functional | Status service responds | `status_server.py --port 8765`; `curl /` and `/status` | HTTP 200, aligned text page and JSON with overall status; one log line per request | As expected | Pass | TC-F06.txt, TC-F06_server_console.txt |
| TC-N01 | COHNDNE252F-008 | Negative | Invalid option | `netwatch.sh -x`; `netwatch.py --bogus` | Usage on stderr, exit 2 in both | As expected | Pass | TC-N01.txt |
| TC-N02 | COHNDNE252F-008 | Negative | Malformed rows: blank line, `8O80`, 99999, 192.168.1.256, missing fields, trailing comma, leading-zero IP, `8_080`, bad critical, `$(id)` in hostname | `netwatch.sh -s -i inventory_malformed.csv` | 10 rows rejected, each with line number and reason; 2 good rows (incl. one with spaces/`YES`) processed | As expected | Pass | TC-N02.txt |
| TC-N03 | COHNDNE252F-010 | Negative | Same file through Part B gives identical decisions (INT-01) | `netwatch.py -i inventory_malformed.csv` | Identical accept/reject list and reasons to TC-N02 | As expected, line for line | Pass | TC-N03.txt vs TC-N02.txt |
| TC-N04 | COHNDNE252F-010 | Negative | Missing inventory file | `-i /nonexistent/inv.csv` to both | Clear message naming the path; exit 4 in both | As expected | Pass | TC-N04.txt |
| TC-N05 | COHNDNE252F-013 | Negative | Invalid timeout value | `netwatch.sh -t abc`; `netwatch.py -t 0` | Usage message, exit 2 in both | As expected | Pass | TC-N05.txt |
| TC-N06 | COHNDNE252F-013 | Negative | Status port already in use | Second server on 8765 | "port 8765 is already in use…", exit 4, no traceback | As expected | Pass | TC-N06.txt |
| TC-N07 | COHNDNE252F-008 | Negative | Output directory cannot be created | `netwatch.sh -o /proc/netwatch_out` | Clear permission error + usage, exit 2 | As expected | Pass | TC-N07.txt |
| TC-N09 | COHNDNE252F-008 | Negative | Unreachable host recorded as DOWN; run continues. Every authorised address answers ping, so `ping` is replaced by a stub that reports no reply (a test double) | `PATH=stub:$PATH netwatch.sh -s` | Every host DOWN with RTT N/A; run completes; exit 3 (critical hosts down) | As expected | Pass | TC-N09.txt |
| TC-N10 | COHNDNE252F-013 | Negative | Probe blocked by local policy | stub `ping` exits 2 ("Operation not permitted") | Warning logged per host with ping's message; hosts DOWN; run completes | As expected | Pass | TC-N10.txt |
| TC-N11 | COHNDNE252F-010 | Negative | Unavailable service: refused vs hung | inventory with 9090 (nothing listening) and 9999 (hung service) | 9090 CLOSED "connection refused" in <1 ms; 9999 TIMEOUT after ~2 s; distinct states | As expected | Pass | TC-N11.txt |
| TC-N08 | COHNDNE252F-010 | Negative | Corrupt previous results file | `results.json` overwritten with invalid JSON | "previous results file is corrupt - treated as first run"; new results saved | As expected | Pass | TC-N08.txt |
| TC-B01 | COHNDNE252F-013 | Boundary | Empty inventory (0 bytes and header-only) | empty.csv, header_only.csv to both | "empty" / "no valid targets – nothing to check", exit 4, no division by zero | As expected | Pass | TC-B01.txt |
| TC-B02 | COHNDNE252F-008 | Boundary | Single-row inventory | single.csv | One target checked, summary correct | As expected | Pass | TC-B02.txt |
| TC-B03 | COHNDNE252F-010 | Boundary | Ports 1 and 65535 accepted; 0 and 65536 rejected | ports.csv | Lines 4–5 rejected; ports 1 and 65535 checked (CLOSED) | As expected | Pass | TC-B03.txt |
| TC-X01 | COHNDNE252F-013 | Failure | Service stopped between runs | Stop 8081, run Part B | "Newly CLOSED (1): 127.0.0.1:8081" | As expected | Pass | TC-X01.txt |
| TC-X02 | COHNDNE252F-008 | Failure | Service restarted | Start 8081, run Part B | "Newly OPENED (1): 127.0.0.1:8081" | As expected | Pass | TC-X02.txt |
| TC-X03 | COHNDNE252F-010 | Failure | Ctrl+C during a Part B run | SIGINT after 1 s, `-t 10 -m sequential` | "Interrupted by user…", exit 130, no traceback | As expected | Pass | TC-X03.txt |
| TC-X04 | COHNDNE252F-013 | Failure | Ctrl+C during a Part A run | SIGINT after 3 s, `-t 10` | Warning message, exit 130, no `.netwatch_tmp*` files left | As expected | Pass | TC-X04.txt |
| TC-X05 | COHNDNE252F-008 | Failure | History deleted between runs | history.csv removed, `netwatch.sh -s` | File recreated with header; run continues | As expected | Pass | TC-X05.txt |

## Error-handling matrix

| Condition | Where | Our behaviour | Test |
|---|---|---|---|
| Inventory file missing or unreadable | Both | Message naming the path; exit 4 | TC-N04 |
| Malformed inventory row | Both | Rejected with line number and reason; processing continues | TC-N02, TC-N03 |
| Port outside 1–65535 or non-numeric | Both | Rejected at validation, before any network operation | TC-N02, TC-B03 |
| Invalid or unresolvable address | Both | Invalid format rejected at validation; a socket error at run time is recorded as `ERROR` for that target and the run continues | TC-N02 |
| Host unreachable | Part A | Recorded as DOWN (RTT N/A); run continues; exit 1, or 3 if critical | TC-N09 (and TC-N10 for a probe blocked by policy) |
| Connection refused | Part B | Recorded as `CLOSED` – a valid finding | TC-N11, TC-B03 |
| Connection timeout | Both | Bounded by `-t`; recorded as `TIMEOUT`, distinct from `CLOSED` | TC-N11 (hung service on 9999) |
| Invalid command-line option or value | Both | Usage on stderr; exit 2 | TC-N01, TC-N05 |
| Output directory missing or unwritable | Both | Created if possible, otherwise a clear permission error | TC-N07, TC-X05 |
| Previous results missing or corrupt | Part B | Stated explicitly and treated as a first run | TC-N08 |
| Status port already in use | Part B | Message naming the port; exit 4 | TC-N06 |
| Interruption with Ctrl+C | Both | Temp files removed; message, not a traceback; exit 130 | TC-X03, TC-X04 |
| Empty history or empty result set | Both | "nothing to report" / "nothing to check"; no division by zero | TC-B01 |
