#!/usr/bin/env bash
#
# Name    : run_tests.sh
# Purpose : Re-runnable test harness for the NetWatch test plan. Each case
#           writes its command, output and exit code to
#           Evidence/tests/<TEST-ID>.txt so a marker can check it.
# Authors : Group 05
# Date    : September 2026
# Usage   : Start the test estate first (README section 3), then
#           ./Evidence/tests/run_tests.sh
# shellcheck disable=SC2016  # bash -c bodies are single-quoted on purpose; they expand in the child
set -uo pipefail   # no -e: many cases are expected to fail

TEST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$TEST_DIR/../.." && pwd)"
PART_A="$ROOT/ShellScript/netwatch.sh"
PART_B="$ROOT/Python/netwatch.py"
SERVER="$ROOT/Python/status_server.py"
SCRATCH="$(mktemp -d)"
trap 'rm -rf -- "$SCRATCH"' EXIT

# record ID DESCRIPTION -- COMMAND...   run COMMAND, save transcript
record() {
    local id="$1"
    local description="$2"
    local out="$TEST_DIR/$id.txt"
    local rc
    shift 3

    {
        printf '# %s - %s\n# Run at: %s\n$ %s\n\n' \
            "$id" "$description" "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$*"
        "$@" 2>&1
        rc=$?
        printf '\n# exit code: %d\n' "$rc"
    } > "$out"
    printf '%-10s exit %-4s %s\n' "$id" "$(tail -n 1 "$out" | awk '{print $NF}')" "$description"
}

cd "$ROOT" || exit 1

# ---- Preflight: the test estate must be running -------------------------
for port in 8080 9000 8081 8888; do
    if ! curl -s -o /dev/null "http://127.0.0.1:$port/"; then
        printf 'Port %d is not answering - start the test estate first (README section 3).\n' "$port" >&2
        exit 1
    fi
done

# ---- Fixtures --------------------------------------------------------
printf 'hostname,ip_address,service,port,critical\n' > "$SCRATCH/header_only.csv"
: > "$SCRATCH/empty.csv"
printf 'hostname,ip_address,service,port,critical\nintranet,127.0.0.1,http,8080,yes\n' \
    > "$SCRATCH/single.csv"
cat > "$SCRATCH/ports.csv" <<'EOF'
hostname,ip_address,service,port,critical
port-min,127.0.0.1,test,1,no
port-max,127.0.0.1,test,65535,no
port-zero,127.0.0.1,test,0,no
port-over,127.0.0.1,test,65536,no
EOF
cp "$TEST_DIR/inventory_malformed.csv" "$SCRATCH/malformed.csv"
printf 'hostname,ip_address,service,port,critical\ntest-server,127.0.0.1,http,9090,no\narchive-app,127.0.0.1,archive,9999,no\n' \
    > "$SCRATCH/unavailable.csv"

# Stub ping commands. Every authorised address answers ping, so to prove
# the DOWN path we put a fake 'ping' first on PATH (a standard test double).
mkdir -p "$SCRATCH/no_reply" "$SCRATCH/blocked"
printf '#!/bin/sh\necho "1 packets transmitted, 0 received, 100%% packet loss"\nexit 1\n' \
    > "$SCRATCH/no_reply/ping"
printf '#!/bin/sh\necho "ping: sendmsg: Operation not permitted" >&2\nexit 2\n' \
    > "$SCRATCH/blocked/ping"
chmod +x "$SCRATCH/no_reply/ping" "$SCRATCH/blocked/ping"

# ---- Functional -------------------------------------------------------
record TC-F01 "Part A full run on valid inventory (invokes Part B)" -- \
    "$PART_A"
record TC-F02 "Part B sequential mode" -- \
    python3 "$PART_B" --mode sequential
record TC-F03 "Part B concurrent mode" -- \
    python3 "$PART_B" --mode concurrent
record TC-F04 "Part B compare mode: both timings, identical result sets" -- \
    python3 "$PART_B" --mode compare
record TC-F05 "Part A report-only mode rebuilds report, no probes" -- \
    "$PART_A" -r

# Background jobs start with SIGINT ignored; restore Python's default
# handler so the kill -INT below behaves exactly like Ctrl+C.
python3 -c 'import runpy, signal, sys
signal.signal(signal.SIGINT, signal.default_int_handler)
sys.argv = [sys.argv[1], "--port", "8765"]
runpy.run_path(sys.argv[0], run_name="__main__")' "$SERVER" \
    > "$SCRATCH/server.out" 2>&1 &
server_pid=$!
sleep 1
record TC-F06 "Status server returns current status (/ and /status)" -- \
    bash -c 'curl -s -i http://127.0.0.1:8765/ ; echo; curl -s http://127.0.0.1:8765/status | head -n 12'

# ---- Negative ---------------------------------------------------------
record TC-N01 "Invalid option (Part A -x, Part B --bogus)" -- \
    bash -c '"$1" -x; echo "[Part A exit $?]"; python3 "$2" --bogus; echo "[Part B exit $?]"' _ "$PART_A" "$PART_B"
record TC-N02 "Malformed rows rejected with line+reason, run continues (Part A)" -- \
    "$PART_A" -s -i "$SCRATCH/malformed.csv" -o "$SCRATCH/part_a_out"
record TC-N03 "Same malformed file in Part B gives identical decisions (INT-01)" -- \
    python3 "$PART_B" -i "$SCRATCH/malformed.csv"
record TC-N04 "Missing inventory file (both parts)" -- \
    bash -c '"$1" -i /nonexistent/inv.csv; echo "[Part A exit $?]"; python3 "$2" -i /nonexistent/inv.csv; echo "[Part B exit $?]"' _ "$PART_A" "$PART_B"
record TC-N05 "Non-numeric and out-of-range timeout (both parts)" -- \
    bash -c '"$1" -t abc; echo "[Part A exit $?]"; python3 "$2" -t 0; echo "[Part B exit $?]"' _ "$PART_A" "$PART_B"
record TC-N06 "Status server port already in use" -- \
    python3 "$SERVER" --port 8765
record TC-N07 "Output directory cannot be created" -- \
    "$PART_A" -o /proc/netwatch_out

kill -INT "$server_pid"
wait "$server_pid" 2>/dev/null
cp "$SCRATCH/server.out" "$TEST_DIR/TC-F06_server_console.txt"

record TC-N09 "Unreachable host recorded as DOWN, run continues (ping stubbed: no reply)" -- \
    env PATH="$SCRATCH/no_reply:$PATH" "$PART_A" -s -o "$SCRATCH/down_out"
record TC-N10 "Probe blocked by local policy logged, host DOWN, run continues (ping stubbed: exit 2)" -- \
    env PATH="$SCRATCH/blocked:$PATH" "$PART_A" -s -o "$SCRATCH/blocked_out"
record TC-N11 "Unavailable services: refused recorded CLOSED, hung recorded TIMEOUT" -- \
    python3 "$PART_B" -i "$SCRATCH/unavailable.csv"

printf '{ this is not json' > "$ROOT/Python/data/results.json"
record TC-N08 "Corrupt previous results file treated as first run" -- \
    python3 "$PART_B"

# ---- Boundary ---------------------------------------------------------
record TC-B01 "Empty (0-byte) and header-only inventory (both parts)" -- \
    bash -c 'for f in "$3" "$4"; do "$1" -i "$f"; echo "[Part A exit $?]"; python3 "$2" -i "$f"; echo "[Part B exit $?]"; done' _ "$PART_A" "$PART_B" "$SCRATCH/empty.csv" "$SCRATCH/header_only.csv"
record TC-B02 "Single-row inventory" -- \
    python3 "$PART_B" -i "$SCRATCH/single.csv"
record TC-B03 "Ports 1 and 65535 accepted; 0 and 65536 rejected" -- \
    python3 "$PART_B" -i "$SCRATCH/ports.csv" -t 0.5

# ---- Failure ----------------------------------------------------------
# The boundary cases above used other inventories; take a fresh baseline
# from the real inventory so change detection compares like with like.
python3 "$PART_B" > /dev/null 2>&1
pkill -f 'http.server 808[1]'; sleep 1
record TC-X01 "Service stopped between runs appears in Newly CLOSED" -- \
    python3 "$PART_B"
mkdir -p /tmp/netwatch_www
nohup python3 -m http.server 8081 --bind 127.0.0.1 --directory /tmp/netwatch_www > /dev/null 2>&1 &
sleep 1
record TC-X02 "Service restarted appears in Newly OPENED" -- \
    python3 "$PART_B"
record TC-X03 "Ctrl+C during Part B run: message, exit 130, no traceback" -- \
    timeout --preserve-status -s INT 1 python3 "$PART_B" -t 10 -m sequential
record TC-X04 "Ctrl+C during Part A run: cleanup, message, exit 130, no temp files left" -- \
    bash -c 'timeout --preserve-status -s INT 3 "$1" -t 10; rc=$?; echo "[exit $rc]"; echo "Temp files left:"; ls -A "$2"/reports | grep "^\.netwatch_tmp" || echo "none"' _ "$PART_A" "$ROOT/ShellScript"
mv "$ROOT/ShellScript/data/history.csv" "$SCRATCH/history.bak"
record TC-X05 "History file deleted between runs is recreated with header" -- \
    bash -c '"$1" -s; echo; head -n 3 "$2"' _ "$PART_A" "$ROOT/ShellScript/data/history.csv"
tail -n +2 "$ROOT/ShellScript/data/history.csv" > "$SCRATCH/history.new"
cat "$SCRATCH/history.bak" "$SCRATCH/history.new" > "$ROOT/ShellScript/data/history.csv"

printf '\nTranscripts written to %s\n' "$TEST_DIR"