#!/usr/bin/env bash
#
# Name    : run_performance.sh
# Purpose : Performance measurement for the report. Runs Part B in
#           compare mode (sequential then concurrent on the same targets)
#           three times for each workload and prints the means.
# Authors : Group 05
# Date    : September 2026
# Usage   : Start the test estate (README section 3), then
#           ./Evidence/performance/run_performance.sh
set -euo pipefail

PERF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$PERF_DIR/../.." && pwd)"
PART_B="$ROOT/Python/netwatch.py"
RANGE_FILE="$PERF_DIR/port_range_inventory.csv"
HUNG_FILE="$PERF_DIR/hung_inventory.csv"
FIRST_PORT=20000
LAST_PORT=20999
HUNG_PORTS=(9990 9991 9992 9993 9994 9995 9996 9997 9998)

# Workload 2: a 1000-port range on one authorised host, plus the four
# test-estate ports so a few targets are open.
{
    printf 'hostname,ip_address,service,port,critical\n'
    for port in 8080 8081 8888 9000; do
        printf 'estate-%d,127.0.0.1,http,%d,no\n' "$port" "$port"
    done
    for (( port = FIRST_PORT; port <= LAST_PORT; port++ )); do
        printf 'range-%d,127.0.0.1,tcp,%d,no\n' "$port" "$port"
    done
} > "$RANGE_FILE"

# Workload 3: nine hung services (listen, never answer) - every check
# waits for the full timeout, which is where concurrency pays off.
{
    printf 'hostname,ip_address,service,port,critical\n'
    for port in "${HUNG_PORTS[@]}"; do
        printf 'hung-%d,127.0.0.1,tcp,%d,no\n' "$port" "$port"
    done
} > "$HUNG_FILE"
python3 "$ROOT/Evidence/stuck_service.py" "${HUNG_PORTS[@]}" > /dev/null &
STUCK_PID=$!
trap 'kill "$STUCK_PID" 2>/dev/null || true' EXIT
sleep 1

# measure LABEL INVENTORY - three compare-mode runs, then the means
measure() {
    local label="$1"
    local inventory="$2"
    local run
    local out
    local rc

    for run in 1 2 3; do
        out="$PERF_DIR/${label}_run${run}.txt"
        rc=0
        python3 "$PART_B" -i "$inventory" -m compare > "$out" 2>&1 || rc=$?
        printf '%s run %d: exit %d, %s | %s\n' "$label" "$run" "$rc" \
            "$(grep 'Sequential :' "$out")" "$(grep 'Concurrent :' "$out")"
    done

    awk -v label="$label" '
        /^Sequential :/ { seq += $3; n++ }
        /^Concurrent :/ { con += $3 }
        END {
            printf "%-12s mean sequential %.3f s, mean concurrent %.3f s, speed-up %.2fx (n=%d)\n",
                label, seq / n, con / n, (con > 0 ? seq / con : 0), n
        }
    ' "$PERF_DIR/${label}"_run*.txt
}

{
    printf 'Performance run %s on %s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$(uname -n)"
    printf 'Timeout 2s, max 20 worker threads\n\n'
    measure "inventory" "$ROOT/ShellScript/config/inventory.csv"
    measure "port_range" "$RANGE_FILE"
    measure "hung_9" "$HUNG_FILE"
} | tee "$PERF_DIR/performance_summary.txt"

# Leave a real-inventory baseline for the next change-detection run.
python3 "$PART_B" > /dev/null 2>&1 || true