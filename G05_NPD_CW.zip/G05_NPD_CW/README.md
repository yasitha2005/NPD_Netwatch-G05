# NetWatch – Network Monitoring Toolkit (Group 05)

HNDNE-25.2F Network Programming Design coursework. NetWatch monitors Serendib Logistics' servers:
**Part A** (Bash) checks that each host is reachable and keeps a history. **Part B** (Python) checks that each
service actually answers on its port, detects changes between runs and publishes the status over HTTP.
Part A runs Part B as one of its stages and merges both results into a single report.

## Group members and work allocation

| Member | ID | Main responsibility | Share |
|---|---|---|---|
| Mr. PERERA S K Y R | COHNDNE252F-008 | Part A (Bash): inventory validation, reachability probes, history and logging library, consolidated report, `set -euo pipefail` and trap handling, cron scheduling | 34% |
| Mr. AKASH K P L | COHNDNE252F-010 | Part B (Python): socket service checks, sequential and concurrent scanning, change detection with sets, results persistence, exit codes, performance measurement | 33% |
| Mr. DIAS K Y S V | COHNDNE252F-013 | Status server, integration of Part A and Part B (INT-01 to INT-03, data contract), test estate, test harness and evidence, security checks | 33% |

All three members worked across both parts, reviewed each other's code, and share the report, diagrams and demonstration.
The full allocation table and signed contribution statements are in Appendix B of `Documentation/Coursework_Report.pdf`.

---

## 1. Requirements

Developed and tested on **CentOS Stream 9** (VirtualBox VM); any Linux with Bash 4.4+, Python 3.8+ and `ping` (iputils) works.
Nothing else needs installing: Python uses the standard library only. `curl` and `shellcheck` are needed only to repeat some tests
(CentOS 9: `sudo dnf install -y curl`; ShellCheck comes from EPEL).

```bash
cd G05_NPD_CW            # the extracted archive
chmod +x ShellScript/netwatch.sh Python/*.py Evidence/*.py Evidence/tests/run_tests.sh Evidence/performance/run_performance.sh
```

## 2. Scanning boundary

NetWatch only ever targets `127.0.0.1`: no lab range was issued, so the whole estate is simulated on
loopback ports, as the brief allows.

## 3. Start the simulated estate (one terminal each, or add `&`)

First run `mkdir -p /tmp/netwatch_www` (an empty folder, so the servers publish nothing).

| Port | Inventory row | Command |
|---|---|---|
| 8080 | intranet (critical) | `python3 -m http.server 8080 --bind 127.0.0.1 --directory /tmp/netwatch_www` |
| 9000 | warehouse-app (critical) | `python3 -m http.server 9000 --bind 127.0.0.1 --directory /tmp/netwatch_www` |
| 8081 | fileserver | `python3 -m http.server 8081 --bind 127.0.0.1 --directory /tmp/netwatch_www` |
| 8888 | reports-web | `python3 -m http.server 8888 --bind 127.0.0.1 --directory /tmp/netwatch_www` |
| 9090 | test-server – **deliberately not started** (nothing listening) | – |
| 2121 | legacy-ftp – **deliberately not started** | – |
| 9999 | archive-app – a **hung** service: listens but never answers, so checks TIMEOUT | `python3 Evidence/stuck_service.py` |

Or start all five from one terminal:

```bash
mkdir -p /tmp/netwatch_www
for p in 8080 9000 8081 8888; do
  nohup python3 -m http.server "$p" --bind 127.0.0.1 --directory /tmp/netwatch_www >/dev/null 2>&1 &
done
nohup python3 Evidence/stuck_service.py >/dev/null 2>&1 &
```

To demonstrate recovery, stop the 8081 server with Ctrl+C, run Part B, then start it again and run Part B again.

## 4. Run it

```bash
./ShellScript/netwatch.sh                       # full pipeline: validate → ping → Part B → report
./ShellScript/netwatch.sh -h                    # help
./ShellScript/netwatch.sh -r                    # report only (no probes, history unchanged)
./ShellScript/netwatch.sh -i path/to/inv.csv -o /tmp/nw -t 1 -s   # custom inventory/output/timeout, skip Part B

python3 Python/netwatch.py                      # Part B alone, concurrent (default)
python3 Python/netwatch.py -m sequential
python3 Python/netwatch.py -m compare           # runs both modes, prints both timings and the speed-up
python3 Python/netwatch.py -i path/to/inv.csv -t 1

python3 Python/status_server.py                 # then open http://127.0.0.1:8000/  (JSON: /status)
python3 Python/status_server.py --port 8100
```

Ctrl+C stops any of the three programs with a message rather than a traceback.

## 5. Exit-code scheme (shared by both parts)

| Code | Meaning | Part A | Part B |
|---|---|---|---|
| 0 | OK – every target UP / OPEN | ✓ | ✓ |
| 1 | WARNING – at least one **non-critical** target down | ✓ | ✓ |
| 2 | USAGE – invalid option or value (usage printed on stderr) | ✓ | ✓ |
| 3 | CRITICAL – at least one **critical** target down | ✓ | ✓ |
| 4 | FATAL – inventory missing/unreadable/empty/no valid rows, output not writable, Part B could not run | ✓ | ✓ |
| 130 | Interrupted by Ctrl+C | ✓ | ✓ |

Part A runs Part B, captures its exit code and exits with the **more severe** of the two, so cron (or anything else) can act on a single number.
The status server exits 0 on a clean stop and 4 if it cannot start.

## 6. Files and data contract

```
ShellScript/config/inventory.csv   input for both parts (the file Dilani edits)
ShellScript/data/history.csv       Part A: one row appended per ping check
ShellScript/logs/netwatch.log      Part A run narrative (includes Part B's full output)
ShellScript/reports/netwatch_<YYYYmmdd_HHMMSS>.txt|.csv   consolidated report (screen copy + CSV)
Python/data/results.json           Part B latest results (read by the status server and the next run)
Python/reports/py_results_<YYYYmmdd_HHMMSS>.csv          Part B results for Part A (INT-03)
Python/logs/netwatch.log           Part B and status-server log (one line per HTTP request)
```

**Inventory** – header row, then `hostname,ip_address,service,port,critical`. Both parts apply the same rules in the same order,
so they accept and reject exactly the same rows: exactly 5 fields (a trailing comma makes 6); hostname and service are `[A-Za-z0-9._-]+`;
IPv4 dotted quad, each octet 0–255, no leading zeros; port is all digits, 1–65535; critical is `yes`/`no` (any case). Surrounding spaces are ignored.
Each rejection names the line number and the reason, and processing continues.

**`py_results_*.csv`** (Part B → Part A): comma-delimited, one header row, **no quoting** (the validation rules forbid commas in any field), fields in this order:
`timestamp,hostname,ip_address,service,port,critical,status,response_time_ms,error`.
`timestamp` is ISO 8601 with a numeric UTC offset, e.g. `2026-09-27T20:15:04+0530`, the same format as `history.csv`.
`status` is one of `OPEN` (connected), `CLOSED` (connection refused), `TIMEOUT` (no reply within the timeout) or `ERROR` (e.g. network unreachable).
Part A joins these results to its own history on **address + port**.

**`history.csv`**: `timestamp,hostname,address,service,port,status,rtt_ms`, where `status` is `UP`/`DOWN` and `rtt_ms` is `N/A` when DOWN.

## 7. Scheduling (cron)

Hourly, using absolute paths (our installation; change `/home/osboxes` to the real home directory).
On CentOS start the scheduler first with `sudo systemctl enable --now crond`.

```cron
0 * * * * /home/osboxes/G05_NPD_CW/ShellScript/netwatch.sh >> /home/osboxes/G05_NPD_CW/Evidence/cron_output.log 2>&1
```

Evidence of a scheduled run is in `Evidence/crontab_evidence.txt` and `Evidence/cron_output.log`.

## 8. Tests, performance and code quality

```bash
./Evidence/tests/run_tests.sh              # 25 cases → Evidence/tests/TC-*.txt (start the estate first)
./Evidence/performance/run_performance.sh  # 3 workloads × 3 runs → Evidence/performance/performance_summary.txt
shellcheck -x ShellScript/netwatch.sh ShellScript/lib/netwatch_lib.sh   # clean
python3 -m py_compile Python/netwatch.py Python/status_server.py
```

The test plan with authors, and the error-handling matrix, are in the report (sections 7 and 8) and in `Evidence/test_plan.md`.

## 9. Documentation

`Documentation/Coursework_Report.pdf`, `Documentation/Network_Architecture.png`, `Documentation/Program_Architecture.png`.
