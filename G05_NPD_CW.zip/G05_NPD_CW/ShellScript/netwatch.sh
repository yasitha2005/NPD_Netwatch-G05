#!/usr/bin/env bash
#
# Name    : netwatch.sh
# Purpose : NetWatch Part A. Reads and validates the shared inventory,
#           pings each host, appends every check to data/history.csv,
#           invokes Part B (Python service checks) and acts on its exit
#           code, then merges Part B's results into one consolidated
#           report shown on screen and saved under reports/.
# Authors : Group 05
# Date    : September 2026
# Usage   : ./netwatch.sh [-i inventory] [-o output_dir] [-t timeout]
#                         [-r] [-s] [-h]
#
# Exit codes (shared with Part B - see README "Exit-code scheme"):
#   0 OK, 1 WARNING (non-critical target down), 2 USAGE,
#   3 CRITICAL (critical target down), 4 FATAL, 130 INTERRUPTED
set -euo pipefail

# ---------------------------------------------------------------------
# Locations - all relative to this script, never to the caller's cwd,
# so cron can run it from anywhere.
# ---------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck source-path=SCRIPTDIR source=lib/netwatch_lib.sh
source "$SCRIPT_DIR/lib/netwatch_lib.sh"

readonly EXIT_OK=0
readonly EXIT_WARNING=1
readonly EXIT_USAGE=2
readonly EXIT_CRITICAL=3
readonly EXIT_FATAL=4
readonly EXIT_INTERRUPTED=130

readonly PART_B_SCRIPT="$PROJECT_DIR/Python/netwatch.py"
readonly PART_B_REPORTS="$PROJECT_DIR/Python/reports"
readonly HISTORY_HEADER="timestamp,hostname,address,service,port,status,rtt_ms"
readonly MAX_TIMEOUT=60

# Defaults - the script runs with no arguments.
INVENTORY_FILE="$SCRIPT_DIR/config/inventory.csv"
OUTPUT_DIR="$SCRIPT_DIR"
PROBE_TIMEOUT="2"
REPORT_ONLY=false
RUN_PART_B=true

# Run state.
declare -a VALID_TARGETS=()
declare -a TMP_FILES=()
valid_count=0
rejected_count=0
PART_A_RC=$EXIT_OK
PART_B_RC=$EXIT_OK

# ---------------------------------------------------------------------
# Cleanup: temporary files are removed on normal exit, Ctrl+C and TERM.
# ---------------------------------------------------------------------
# shellcheck disable=SC2317,SC2329  # called by trap, which shellcheck cannot see
cleanup() {
    local file

    for file in ${TMP_FILES[@]+"${TMP_FILES[@]}"}; do
        if [[ -n "$file" && -e "$file" ]]; then
            rm -f -- "$file"
        fi
    done
}

# shellcheck disable=SC2317,SC2329  # called by trap, which shellcheck cannot see
on_interrupt() {
    printf '\n' >&2
    log_warn "Interrupted by user - temporary files removed; checks already recorded are kept"
    exit "$EXIT_INTERRUPTED"
}

# shellcheck disable=SC2317,SC2329  # called by trap, which shellcheck cannot see
on_terminate() {
    log_warn "Terminated - temporary files removed"
    exit 143
}

trap cleanup EXIT
trap on_interrupt INT
trap on_terminate TERM

usage() {
    cat >&2 <<EOF
Usage: $(basename "$0") [OPTIONS]

NetWatch Part A - reachability monitor and consolidated report

Options:
  -i PATH     Inventory CSV            (default: $SCRIPT_DIR/config/inventory.csv)
  -o DIR      Output directory; data/, logs/ and reports/ go under it
                                       (default: $SCRIPT_DIR)
  -t SECONDS  Probe timeout, 0 < t <= $MAX_TIMEOUT (default: 2)
  -r          Report-only: rebuild the report from history, no probes
  -s          Skip the Part B stage (reachability only)
  -h          Show this help and exit 0

Exit codes: 0 OK, 1 WARNING, 2 USAGE, 3 CRITICAL, 4 FATAL, 130 INTERRUPTED
EOF
}

usage_error() {
    local message="$1"

    log_error "$message"
    usage
    exit "$EXIT_USAGE"
}

# ---------------------------------------------------------------------
# FR-S02 - command-line interface
# ---------------------------------------------------------------------
parse_arguments() {
    local option

    while getopts ":i:o:t:rsh" option; do
        case "$option" in
            i) INVENTORY_FILE="$OPTARG" ;;
            o) OUTPUT_DIR="$OPTARG" ;;
            t) PROBE_TIMEOUT="$OPTARG" ;;
            r) REPORT_ONLY=true ;;
            s) RUN_PART_B=false ;;
            h) usage; exit "$EXIT_OK" ;;
            :) usage_error "Option -$OPTARG requires an argument" ;;
            \?) usage_error "Unknown option: -$OPTARG" ;;
        esac
    done
    shift $((OPTIND - 1))

    if (( $# > 0 )); then
        usage_error "Unexpected argument: $1"
    fi

    if ! [[ "$PROBE_TIMEOUT" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
        usage_error "Timeout must be a positive number of seconds: '$PROBE_TIMEOUT'"
    fi

    if ! awk -v t="$PROBE_TIMEOUT" -v max="$MAX_TIMEOUT" \
            'BEGIN { exit !(t > 0 && t <= max) }'; then
        usage_error "Timeout must be greater than 0 and at most $MAX_TIMEOUT: '$PROBE_TIMEOUT'"
    fi
}

# Create data/, logs/ and reports/ under the output directory, or stop
# with a clear permission error.
prepare_output() {
    local dir

    DATA_DIR="$OUTPUT_DIR/data"
    LOG_DIR="$OUTPUT_DIR/logs"
    REPORTS_DIR="$OUTPUT_DIR/reports"

    for dir in "$OUTPUT_DIR" "$DATA_DIR" "$LOG_DIR" "$REPORTS_DIR"; do
        if ! mkdir -p -- "$dir" 2>/dev/null || [[ ! -w "$dir" ]]; then
            usage_error "Output directory cannot be created or is not writable: $dir"
        fi
    done

    NETWATCH_LOG_FILE="$LOG_DIR/netwatch.log"
}

# ---------------------------------------------------------------------
# FR-S01 - read and validate the inventory, row by row.
# Same rules and order as validate_row() in Part B (INT-01).
# ---------------------------------------------------------------------
validate_inventory() {
    local line
    local line_number=0
    local commas
    local field_count
    local reason
    local hostname ip_address service port critical

    if [[ ! -e "$INVENTORY_FILE" ]]; then
        log_error "Inventory file not found: $INVENTORY_FILE"
        return 1
    fi
    if [[ ! -f "$INVENTORY_FILE" || ! -r "$INVENTORY_FILE" ]]; then
        log_error "Inventory file is not a readable file: $INVENTORY_FILE"
        return 1
    fi
    if [[ ! -s "$INVENTORY_FILE" ]]; then
        log_error "Inventory file is empty: $INVENTORY_FILE"
        return 1
    fi

    log_info "Reading inventory: $INVENTORY_FILE"

    while IFS= read -r line || [[ -n "$line" ]]; do
        line_number=$((line_number + 1))

        # Line 1 is the header row.
        if (( line_number == 1 )); then
            continue
        fi

        reason=""

        if [[ -z "${line//[[:space:]]/}" ]]; then
            reason="blank line"
        else
            # Count fields by counting commas: a trailing comma makes six.
            commas="${line//[^,]/}"
            field_count=$(( ${#commas} + 1 ))

            if (( field_count != 5 )); then
                reason="wrong field count ($field_count, expected 5)"
            else
                IFS=',' read -r hostname ip_address service port critical <<< "$line"
                hostname="$(trim "$hostname")"
                ip_address="$(trim "$ip_address")"
                service="$(trim "$service")"
                port="$(trim "$port")"
                critical="$(trim "$critical")"
                critical="${critical,,}"

                if ! is_valid_name "$hostname"; then
                    reason="invalid hostname '$hostname'"
                elif ! is_valid_ipv4 "$ip_address"; then
                    reason="invalid IPv4 address '$ip_address'"
                elif ! is_valid_name "$service"; then
                    reason="invalid service '$service'"
                elif ! is_valid_port "$port"; then
                    reason="invalid port '$port' (must be 1-65535)"
                elif [[ "$critical" != "yes" && "$critical" != "no" ]]; then
                    reason="critical must be 'yes' or 'no', got '$critical'"
                fi
            fi
        fi

        if [[ -n "$reason" ]]; then
            log_error "Line $line_number rejected: $reason"
            rejected_count=$((rejected_count + 1))
            continue
        fi

        # '|' is safe as an internal separator: validation forbids it.
        VALID_TARGETS+=("$hostname|$ip_address|$service|$((10#$port))|$critical")
        valid_count=$((valid_count + 1))
        log_info "Line $line_number accepted: $hostname $ip_address $service $port $critical"
    done < "$INVENTORY_FILE"

    log_info "Inventory: $valid_count accepted, $rejected_count rejected"
}

# ---------------------------------------------------------------------
# FR-S03 - one bounded ping per target.
# The set -e / failed-probe conflict is resolved here: ping runs as the
# condition of an 'if', and set -e never fires on a command whose status
# is being tested. A DOWN host is a result, not an error.
# Prints: STATUS|RTT
# ---------------------------------------------------------------------
probe_host() {
    local ip_address="$1"
    local ping_output
    local ping_rc=0
    local rtt_ms="N/A"

    if ping_output="$(ping -n -c 1 -W "$PROBE_TIMEOUT" "$ip_address" 2>&1)"; then
        rtt_ms="$(sed -n 's/.*time=\([0-9.]*\) ms.*/\1/p' <<< "$ping_output")"
        printf 'UP|%s\n' "${rtt_ms:-N/A}"
        return 0
    else
        ping_rc=$?
    fi

    # ping exits 1 for "no reply"; 2 or more for an error such as a
    # local firewall policy or no permission to send ICMP.
    if (( ping_rc >= 2 )); then
        log_warn "Ping to $ip_address failed (exit $ping_rc): ${ping_output##*$'\n'}"
    fi
    printf 'DOWN|N/A\n'
}

# ---------------------------------------------------------------------
# FR-S04 - append-only history
# ---------------------------------------------------------------------
prepare_history_file() {
    local history_file="$DATA_DIR/history.csv"

    if [[ ! -s "$history_file" ]]; then
        printf '%s\n' "$HISTORY_HEADER" > "$history_file"
        log_info "Created history file: $history_file"
    fi
}

record_history() {
    local hostname="$1"
    local ip_address="$2"
    local service="$3"
    local port="$4"
    local status="$5"
    local rtt_ms="$6"

    printf '%s,%s,%s,%s,%s,%s,%s\n' \
        "$(timestamp)" "$hostname" "$ip_address" "$service" "$port" \
        "$status" "$rtt_ms" >> "$DATA_DIR/history.csv"
    write_log "INFO" "Recorded $hostname $ip_address $service $port $status rtt=$rtt_ms"
}

run_probes() {
    local target
    local hostname ip_address service port critical
    local result status rtt_ms
    local up=0
    local down=0
    local critical_down=0

    log_info "Stage 1: reachability probes (timeout ${PROBE_TIMEOUT}s)"
    printf '%-18s %-15s %-8s %6s  %-6s %s\n' \
        "HOSTNAME" "ADDRESS" "SERVICE" "PORT" "STATUS" "RTT (ms)"

    for target in "${VALID_TARGETS[@]}"; do
        IFS='|' read -r hostname ip_address service port critical <<< "$target"

        result="$(probe_host "$ip_address")"
        status="${result%%|*}"
        rtt_ms="${result#*|}"

        printf '%-18s %-15s %-8s %6s  %-6s %s\n' \
            "$hostname" "$ip_address" "$service" "$port" "$status" "$rtt_ms"

        record_history "$hostname" "$ip_address" "$service" "$port" "$status" "$rtt_ms"

        if [[ "$status" == "UP" ]]; then
            up=$((up + 1))
        else
            down=$((down + 1))
            if [[ "$critical" == "yes" ]]; then
                critical_down=$((critical_down + 1))
            fi
        fi
    done

    log_info "Reachability: $up UP, $down DOWN ($critical_down critical) of $valid_count"

    if (( critical_down > 0 )); then
        PART_A_RC=$EXIT_CRITICAL
    elif (( down > 0 )); then
        PART_A_RC=$EXIT_WARNING
    fi
}

# Newest Part B CSV. File names embed YYYYmmdd_HHMMSS, so glob order
# (alphabetical) is also time order and the last match is the newest.
latest_part_b_file() {
    local file
    local latest=""

    for file in "$PART_B_REPORTS"/py_results_*.csv; do
        if [[ -f "$file" ]]; then
            latest="$file"
        fi
    done
    printf '%s' "$latest"
}

# ---------------------------------------------------------------------
# FR-S05 / INT-03 - consolidated report.
# One awk pass reads Part B's CSV and then the history, and writes the
# on-screen table and the timestamped CSV together.
# ---------------------------------------------------------------------
generate_report() {
    local history_file="$DATA_DIR/history.csv"
    local stamp
    local report_txt
    local report_csv
    local part_b_file
    local part_b_input="/dev/null"
    local check_count=0
    local tmp_txt=""
    local tmp_csv=""
    local file
    local -a failure_inputs

    stamp="$(date '+%Y%m%d_%H%M%S')"
    report_txt="$REPORTS_DIR/netwatch_${stamp}.txt"
    report_csv="$REPORTS_DIR/netwatch_${stamp}.csv"
    part_b_file="$(latest_part_b_file)"

    if [[ -n "$part_b_file" ]]; then
        part_b_input="$part_b_file"
    else
        log_warn "No Part B results found in $PART_B_REPORTS - service columns will show N/A"
    fi

    if [[ -f "$history_file" ]]; then
        check_count="$(awk -F',' '$1 != "timestamp" && NF >= 6 { n++ } END { print n + 0 }' "$history_file")"
    fi

    if (( check_count == 0 )); then
        log_info "History is missing or empty - nothing to report yet"
        printf 'NetWatch report %s\nNo checks recorded yet - nothing to report.\n' \
            "$(timestamp)" > "$report_txt"
        return 0
    fi

    failure_inputs=("$history_file")
    for file in "$PART_B_REPORTS"/py_results_*.csv; do
        if [[ -f "$file" ]]; then
            failure_inputs+=("$file")
        fi
    done

    tmp_txt="$(mktemp "$REPORTS_DIR/.netwatch_tmp.XXXXXX")"
    tmp_csv="$(mktemp "$REPORTS_DIR/.netwatch_tmp.XXXXXX")"
    TMP_FILES+=("$tmp_txt" "$tmp_csv")

    {
        printf '\n%s\n' "=========================================================================================================="
        printf ' NetWatch consolidated report - %s\n' "$(timestamp)"
        printf ' History    : %s (%d checks)\n' "$history_file" "$check_count"
        printf ' Part B file: %s\n' "${part_b_file:-none}"
        printf '%s\n' "=========================================================================================================="

        sort -t',' -k2,2 -k5,5n "$history_file" |
        awk -F',' -v pb="$part_b_input" -v csv_out="$tmp_csv" '
            # First file: Part B results, keyed by address and port.
            FILENAME == pb {
                if ($1 == "timestamp") next
                key = $3 "|" $5
                svc_state[key] = $7
                svc_time[key] = $1
                svc_count[$7]++
                svc_total++
                next
            }
            # Second input: the sorted history.
            $1 == "timestamp" || NF < 6 { next }
            {
                key = $2 "|" $3 "|" $4 "|" $5
                if (!(key in checks)) { order[++n] = key }
                checks[key]++
                if ($6 == "UP") { up[key]++; total_up++ } else { down[key]++ }
                if ($7 ~ /^[0-9.]+$/) { rtt_sum[key] += $7; rtt_n[key]++ }
                last[key] = $6
                total++
            }
            END {
                printf "\n %-10s %d\n %-10s %d\n %-10s %d\n %-10s %.1f%%\n", \
                    "Checks", total, "UP", total_up, "DOWN", total - total_up, \
                    "Available", (total > 0 ? total_up * 100 / total : 0)

                if (svc_total > 0) {
                    printf "\n Service checks (Part B): %d total - OPEN %d, CLOSED %d, TIMEOUT %d, ERROR %d\n", \
                        svc_total, svc_count["OPEN"], svc_count["CLOSED"], \
                        svc_count["TIMEOUT"], svc_count["ERROR"]
                } else {
                    printf "\n Service checks (Part B): no results available\n"
                }

                printf "\n %-18s %-15s %-8s %6s %6s %5s %5s %7s %8s %-5s %-8s\n", \
                    "HOSTNAME", "ADDRESS", "SERVICE", "PORT", "CHECKS", "UP", \
                    "DOWN", "AVAIL%", "AVG RTT", "LAST", "SERVICE"
                printf " %s\n", "---------------------------------------------------------------------------------------------------------"

                print "hostname,ip_address,service,port,checks,up,down,availability_pct,avg_rtt_ms,last_ping,service_state,service_checked_at" > csv_out

                for (i = 1; i <= n; i++) {
                    key = order[i]
                    split(key, f, "|")
                    avail = checks[key] > 0 ? up[key] * 100 / checks[key] : 0
                    rtt = rtt_n[key] > 0 ? sprintf("%.3f", rtt_sum[key] / rtt_n[key]) : "N/A"
                    skey = f[2] "|" f[4]
                    state = (skey in svc_state) ? svc_state[skey] : "N/A"
                    when = (skey in svc_state) ? svc_time[skey] : ""

                    printf " %-18s %-15s %-8s %6s %6d %5d %5d %6.1f%% %8s %-5s %-8s\n", \
                        f[1], f[2], f[3], f[4], checks[key], up[key], down[key], \
                        avail, rtt, last[key], state
                    printf "%s,%s,%s,%s,%d,%d,%d,%.1f,%s,%s,%s,%s\n", \
                        f[1], f[2], f[3], f[4], checks[key], up[key], down[key], \
                        avail, rtt, last[key], state, when > csv_out
                }
            }
        ' "$part_b_input" -

        # Failures = DOWN pings from history plus non-OPEN service checks
        # from every Part B run, counted only for targets Part A monitors.
        printf '\n Top 3 failing services (DOWN pings + non-OPEN service checks, all runs)\n'
        awk -F',' -v hist="$history_file" '
            $1 == "timestamp" || NF < 6 { next }
            FILENAME == hist {
                key = $2 "," $3 "," $4 "," $5
                known[key] = 1
                if ($6 != "UP") { fails[key]++ }
                next
            }
            ($2 "," $3 "," $4 "," $5) in known && $7 != "OPEN" {
                fails[$2 "," $3 "," $4 "," $5]++
            }
            END { for (k in fails) print fails[k] "," k }
        ' "${failure_inputs[@]}" |
        sort -t',' -k1,1nr -k2,2 -k5,5n |
        awk -F',' '
            NR <= 3 { printf " %d. %-18s %-15s %-8s %6s  %d failures\n", NR, $2, $3, $4, $5, $1 }
            END { if (NR == 0) print " No failures recorded." }
        '
        printf '%s\n' "=========================================================================================================="
    } | tee "$tmp_txt"

    mv -- "$tmp_txt" "$report_txt"
    mv -- "$tmp_csv" "$report_csv"
    log_info "Report saved: $report_txt"
    log_info "Report CSV saved: $report_csv"
}

# ---------------------------------------------------------------------
# INT-02 - invoke Part B, capture its exit code and act on it.
# '|| rc=$?' is the same set -e technique as the probe: the exit status
# is consumed, so a non-zero code from Part B does not end this script.
# ---------------------------------------------------------------------
run_part_b() {
    local rc=0
    local output_file

    log_info "Stage 2: invoking Part B service checks"

    if ! command -v python3 >/dev/null 2>&1; then
        log_error "python3 not found - Part B stage could not run"
        PART_B_RC=$EXIT_FATAL
        return 0
    fi
    if [[ ! -f "$PART_B_SCRIPT" ]]; then
        log_error "Part B script not found: $PART_B_SCRIPT"
        PART_B_RC=$EXIT_FATAL
        return 0
    fi

    # Registered in TMP_FILES here, in the main shell, so cleanup sees it.
    output_file="$(mktemp "$REPORTS_DIR/.netwatch_tmp.XXXXXX")"
    TMP_FILES+=("$output_file")

    python3 "$PART_B_SCRIPT" \
        --inventory "$INVENTORY_FILE" \
        --timeout "$PROBE_TIMEOUT" \
        --mode concurrent > "$output_file" 2>&1 || rc=$?

    # Keep Part B's full narrative in our log; show its status line.
    {
        printf '%s [INFO] ---- Part B output begins ----\n' "$(timestamp)"
        cat -- "$output_file"
        printf '%s [INFO] ---- Part B output ends (exit %d) ----\n' "$(timestamp)" "$rc"
    } >> "$NETWATCH_LOG_FILE"

    case "$rc" in
        0|1|3)
            PART_B_RC=$rc
            log_info "Part B: $(grep '^STATUS:' "$output_file" || printf 'finished with exit %d' "$rc")"
            # Show Part B's change lists on screen (demo step 5).
            sed -n '/^Change detection/,/^Unchanged\|^No change lists/p' "$output_file"
            ;;
        130)
            log_warn "Part B was interrupted"
            exit "$EXIT_INTERRUPTED"
            ;;
        *)
            PART_B_RC=$EXIT_FATAL
            log_error "Part B failed (exit $rc): $(grep -m 1 'ERROR' "$output_file" || printf 'see %s' "$NETWATCH_LOG_FILE")"
            ;;
    esac
}

# Larger of two exit codes - the more severe outcome wins.
worst_of() {
    local first="$1"
    local second="$2"

    if (( first > second )); then
        printf '%d' "$first"
    else
        printf '%d' "$second"
    fi
}


main() {
    local final_rc
    local label

    parse_arguments "$@"
    prepare_output

    log_info "NetWatch Part A started (inventory: $INVENTORY_FILE, output: $OUTPUT_DIR)"

    if [[ "$REPORT_ONLY" == true ]]; then
        log_info "Report-only mode: no probes, history unchanged"
        generate_report
        exit "$EXIT_OK"
    fi

    if ! validate_inventory; then
        exit "$EXIT_FATAL"
    fi

    if (( valid_count == 0 )); then
        log_error "No valid targets in the inventory - nothing to check"
        exit "$EXIT_FATAL"
    fi

    prepare_history_file
    run_probes

    if [[ "$RUN_PART_B" == true ]]; then
        run_part_b
    else
        log_info "Stage 2 skipped (-s)"
    fi

    log_info "Stage 3: consolidated report"
    generate_report

    final_rc="$(worst_of "$PART_A_RC" "$PART_B_RC")"
    case "$final_rc" in
        0) label="OK" ;;
        1) label="WARNING" ;;
        3) label="CRITICAL" ;;
        *) label="FATAL" ;;
    esac
    log_info "STATUS: $label (Part A exit $PART_A_RC, Part B exit $PART_B_RC) - exit $final_rc"
    exit "$final_rc"
}

main "$@"
