#!/usr/bin/env bash
# shellcheck shell=bash
#
# Name    : netwatch_lib.sh
# Purpose : Shared helpers for NetWatch Part A - logging, timestamps and
#           the field validators used on every inventory row.
#           Sourced by netwatch.sh; never run directly.
# Authors : Group 05
# Date    : September 2026
#
# The validators here apply the same rules, in the same order, as
# validate_row() in Python/netwatch.py, so both components accept and
# reject exactly the same rows (INT-01).

# Set by netwatch.sh once the output directory is known. Until then,
# messages go to the terminal only.
NETWATCH_LOG_FILE="${NETWATCH_LOG_FILE:-}"

# timestamp - current time in the shared data-contract format,
# e.g. 2026-09-27T20:15:04+0530 (ISO 8601, numeric UTC offset).
timestamp() {
    date '+%Y-%m-%dT%H:%M:%S%z'
}

# write_log LEVEL MESSAGE - append one line to the log file, if set.
write_log() {
    local level="$1"
    local message="$2"

    if [[ -n "$NETWATCH_LOG_FILE" ]]; then
        printf '%s [%s] %s\n' "$(timestamp)" "$level" "$message" \
            >> "$NETWATCH_LOG_FILE"
    fi
}

# log_info MESSAGE - informational: standard output and the log.
log_info() {
    local message="$1"

    printf '[INFO] %s\n' "$message"
    write_log "INFO" "$message"
}

# log_warn MESSAGE - a problem the run survives: standard error and the log.
log_warn() {
    local message="$1"

    printf '[WARN] %s\n' "$message" >&2
    write_log "WARN" "$message"
}

# log_error MESSAGE - an error: standard error and the log.
log_error() {
    local message="$1"

    printf '[ERROR] %s\n' "$message" >&2
    write_log "ERROR" "$message"
}

# trim VALUE - strip leading and trailing whitespace (including a Windows
# carriage return) with parameter expansion, no external command.
trim() {
    local value="$1"

    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"
    printf '%s' "$value"
}

# is_valid_name VALUE - letters, digits, dot, underscore, hyphen only.
# Used for hostname and service; keeps commas, quotes, spaces and shell
# metacharacters out of every file we write.
is_valid_name() {
    local value="$1"

    [[ "$value" =~ ^[A-Za-z0-9._-]+$ ]]
}

# is_valid_ipv4 VALUE - dotted quad, each octet 0-255, no leading zeros.
is_valid_ipv4() {
    local ip="$1"
    local octet='(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])'

    [[ "$ip" =~ ^${octet}\.${octet}\.${octet}\.${octet}$ ]]
}

# is_valid_port VALUE - 1 to 5 digits, value 1-65535.
is_valid_port() {
    local port="$1"

    [[ "$port" =~ ^[0-9]{1,5}$ ]] || return 1
    (( 10#$port >= 1 && 10#$port <= 65535 ))
}